import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { TimelineListComponent } from './timeline-list/timeline-list.component';
import { TimelineComponent } from './timeline/timeline.component';
import { CardService } from './card.service';
import { TimelineService } from './timeline.service';
import { TimelineEditComponent } from './timeline-edit/timeline-edit.component';
import { CardDetailComponent } from './card-detail/card-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    TopBarComponent,
    TimelineListComponent,
    TimelineComponent,
    TimelineEditComponent,
    CardDetailComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: TimelineListComponent },
      { path: 'timeline/:timelineId', component: TimelineComponent },
      { path: 'edit/:timelineId', component: TimelineEditComponent },
    ])
  ],
  providers: [CardService, TimelineService],
  bootstrap: [AppComponent]
})
export class AppModule { }
