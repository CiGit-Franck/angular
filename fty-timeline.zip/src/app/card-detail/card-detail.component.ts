import { Component, OnInit } from "@angular/core";
import { FormBuilder, ReactiveFormsModule } from "@angular/forms";
import { TimelineService } from '../timeline.service';
import { Card } from '../card';

@Component({
  selector: "app-card-detail",
  templateUrl: "./card-detail.component.html",
  styleUrls: ["./card-detail.component.css"]
})
export class CardDetailComponent implements OnInit {
  private cardForm;
  private cards=[];

  constructor(
    private timelinService: TimelineService, 
    private formBuilder: FormBuilder
    ) {
    this.cardForm = this.formBuilder.group({
      id: '0',
      name: '',
      date: '',
      imageUrl: '',
      description: ''
    });
  }

  ngOnInit() {
    this.cards = this.timelinService.getTimeline().cardList;
  }

  onSubmit(item: Card){
    console.log('add : '+item.name);
    this.cards.push(item);
  }
}
