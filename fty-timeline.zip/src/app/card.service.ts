import { Injectable, OnInit } from "@angular/core";
import { TimelineService } from './timeline.service';
import { Card } from "./card";

@Injectable({
  providedIn: "root"
})
export class CardService {

  private cards = [];
  private cardsFounded = [];
  private cardsUnfounded = [];

  constructor(private timelineService: TimelineService) {  
    this.cards = this.timelineService.getTimeline().cardList;
    this.cardsFounded = [];
    this.cardsUnfounded = [];
    for (const card of this.cards) {
      this.cardsUnfounded.push(card);
    }
  }

  ngOnInit() {
  }

  getCardsFounded() {
    return this.cardsFounded;
  }

  getCardsUnfounded() {
    return this.cardsUnfounded;
  }

  getRandomCard(): Card {
    const index = Math.floor(Math.random() * this.cardsUnfounded.length);
    return this.cardsUnfounded[index];
  }

  findCard(card: Card) {
    this.cardsFounded.push(card);
    const index = this.cardsUnfounded.indexOf(card);
    this.cardsUnfounded.splice(index, 1);
  }
}
