export class Card {
  id: number;
  name: string;
  date: Date;
  imageUrl: string;
  description: string;
}
