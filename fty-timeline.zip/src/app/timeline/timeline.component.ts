import { Component, OnInit } from '@angular/core';
import { ViewChild, ElementRef } from '@angular/core';
import { Card } from '../card';
import { CardService } from '../card.service';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})

export class TimelineComponent implements OnInit {

  @ViewChild('dateInput', {static: false}) dateInput: ElementRef;

  cardGuess: Card;
  cardsFounded: Card[];
  cardsUnfounded: Card[];
  idCurrentTimeline: number;

  constructor(private cardService: CardService) { }

  ngOnInit() {
    this.cardGuess = this.cardService.getRandomCard();
    this.cardsFounded = this.cardService.getCardsFounded();
    this.cardsUnfounded = this.cardService.getCardsUnfounded();
  }

  guessCard(card: Card) {
    const yearGuess: number = +this.dateInput.nativeElement.value;
    const dateMatch: Date = new Date(card.date);
    const yearMatch: number = dateMatch.getFullYear();
    
    if (yearGuess === yearMatch) {
      this.cardService.findCard(card);
      this.cardsFounded = this.cardService.getCardsFounded();
    }
    
    if (!this.haveNoCardInUnfounded()) {
      this.cardGuess = this.cardService.getRandomCard();
    }
  }

  haveNoCardInUnfounded(): boolean {
    return !(this.cardsUnfounded.length > 0);
  }
}
