import { Card } from './card';

export class Timeline {
  id: number;
  name: string;
  creationDate: Date;
  updateDate: Date;
  category: string;
  cardList: Card[];
}
