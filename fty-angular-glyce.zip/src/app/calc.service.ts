import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class CalcService {

  items = [];

  constructor() { }

  addToCalc(item) {
    this.items.push(item);
  }

  getItems() {
    return this.items;
  }
}
