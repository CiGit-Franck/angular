import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ListService } from '../list.service';
import { FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-aliment-details',
  templateUrl: './aliment-details.component.html',
  styleUrls: ['./aliment-details.component.css']
})

export class AlimentDetailsComponent implements OnInit {

  private detailForm;

  constructor(private route: ActivatedRoute, private listService: ListService, private formBuilder: FormBuilder) { 
    this.detailForm = this.formBuilder.group({
      ig: '0',
      carbs: '0',
      name: ''
    });
  }

  ngOnInit() { }

  onSubmit(aliment) {
    // console.log(aliment);
    this.addToList(aliment)
  }

 addToList(aliment) {
      this.listService.addToList(aliment);
  }

}
