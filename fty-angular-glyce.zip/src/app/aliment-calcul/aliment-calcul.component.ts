import { Component, OnInit } from '@angular/core';
import { CalcService } from '../calc.service';
import { ListService } from '../list.service';
import { FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-aliment-calcul',
  templateUrl: './aliment-calcul.component.html',
  styleUrls: ['./aliment-calcul.component.css']
})

export class AlimentCalculComponent implements OnInit {

  items;
  list;
  charges;
  private calcForm;

  constructor(
    private listService: ListService,
    private calcService: CalcService,
    private formBuilder: FormBuilder
    ) {
    this.calcForm = this.formBuilder.group({
      aliment: null,
      quantity: 0
    });
  }

  ngOnInit() {
    this.items = this.calcService.getItems();
    this.list = this.listService.getItems();
    this.charges = 0.0;
  }


  onSubmit(item) {
    // console.log(item);
    this.addToCalc(item)
  }

  addToCalc(item) {
    let aliment = item.aliment;
    let charge = (aliment.ig * aliment.carbs) / 100;
    let sum = charge;
    item.quantity = charge;
    this.calcService.getItems().forEach(element => {
      sum += element.quantity;
    });
    this.charges = sum;
    this.calcService.addToCalc(item);
  }

  calc() {
    let sum = 0;
    this.calcService.getItems().forEach(element => {
      sum += element.quantity;
    });
    this.charges = sum;
  }

}
