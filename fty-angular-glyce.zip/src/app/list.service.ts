import { Injectable } from '@angular/core';
import { aliments } from './aliments';

@Injectable({
  providedIn: 'root'
})

export class ListService {

  list = [];

  constructor() {
    this.list = aliments;
  }

  getItems() {
    return this.list;
  }

  addToList(aliment){
    this.list.push(aliment);
  }
}
