import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { AlimentListComponent } from './aliment-list/aliment-list.component';
import { AlimentDetailsComponent } from './aliment-details/aliment-details.component';
import { AlimentCalculComponent } from './aliment-calcul/aliment-calcul.component';
import { CalcService } from './calc.service';
import { ListService } from './list.service';

@NgModule({
  declarations: [
    AppComponent,
    TopBarComponent,
    AlimentListComponent,
    AlimentDetailsComponent,
    AlimentCalculComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: 'list', component: AlimentListComponent },
      { path: 'calculator', component: AlimentCalculComponent },
    ])
],
  providers: [CalcService, ListService],
  bootstrap: [AppComponent]
})
export class AppModule { }
