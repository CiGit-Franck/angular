import { Component, OnInit } from '@angular/core';
import { ListService } from '../list.service';

@Component({
  selector: 'app-aliment-list',
  templateUrl: './aliment-list.component.html',
  styleUrls: ['./aliment-list.component.css']
})

export class AlimentListComponent implements OnInit {

  aliments;

  constructor(private listService: ListService) { }

  ngOnInit() {
    this.aliments = this.listService.getItems();
  }
}
